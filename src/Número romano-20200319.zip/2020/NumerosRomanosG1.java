public class NumerosRomanos {

    public String numberToRoman (int number){
        if (number < 10) return tillTen(number);
        if (number <= 100) return tillHundred(number);
        if (number <=1000) return  tillThousand(number);
        else return "";
    }

    private String tillThousand(int number) {
        int n = number/100;
        switch (n){
            case 1:
                return "C" + tillHundred(number-(n*100));
            case 2:
                return "CC" + tillHundred(number-(n*100));
            case 3:
                return "CCC" + tillHundred(number-(n*100));
            case 4:
                return "CD" + tillHundred(number-(n*100));
            case 5:
                return "D" + tillHundred(number-(n*100));
            case 6:
                return "DC" + tillHundred(number-(n*100));
            case 7:
                return "DCC" + tillHundred(number-(n*100));
            case 8:
                return "DCCC" + tillHundred(number-(n*100));
            case 9:
                return "CM" + tillHundred(number-(n*100));
            case 10:
                return "M" + tillHundred(number-(n*100));

        }
        return "";
    }

    private String tillHundred(int number) {
        int n = number/10;
        switch (n){
            case 1:
                return "X" + tillTen(number-(n*10));
            case 2:
                return "XX" + tillTen(number-(n*10));
            case 3:
                return "XXX" + tillTen(number-(n*10));
            case 4:
                return "XL" + tillTen(number-(n*10));
            case 5:
                return "L" + tillTen(number-(n*10));
            case 6:
                return "LX" + tillTen(number-(n*10));
            case 7:
                return "LXX" + tillTen(number-(n*10));
            case 8:
                return "LXXX" + tillTen(number-(n*10));
            case 9:
                return "XC" + tillTen(number-(n*10));
            case 10:
                return "C" + tillTen(number-(n*10));

        }
        return "";
    }

    public String tillTen (int number){
        switch (number){
            case 1:
            return "I";
            case 2:
                return "II";
            case 3:
                return "III";
            case 4:
                return "IV";
                case 5:
                return "V";
            case 6:
                return "VI";
            case 7:
                return "VII";
            case 8:
                return "VIII";
            case 9:
                return "IX";
        }

        return "";
    }
}
