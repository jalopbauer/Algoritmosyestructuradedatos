public class RomanCharacterConversor {

    public static void main(String[] args) {
        System.out.println(convertToRomanCharacters(Scanner.getInt("Number:")));
    }

    public static String convertToRomanCharacters(int number){
        String value="";



        if (!(number>1000 || number<1)){
            if (number>=900){
                value="CM";
                number=number-900;
            }else if (number>=500 && number<600){
                value="D";
                number=number-500;
            }else if (number>=600 && number<700){
                value="DC";
                number-=600;
            }else if (number>=700 && number<800){
                value="DCC";
                number-=700;
            }else if (number>=800 && number<900){
                value="DCCC";
                number-=800;
            }else if (number>=400 && number<500){
                value="CD";
                number-=400;
            }else if (number>=300 && number<400){
                value="CCC";
                number-=300;
            }else if (number>=200 && number<300){
                value="CC";
                number-=200;
            }else if (number>=100 && number<200){
                value="C";
                number-=100;
            }

            if (number>=90){
                value=value+"XC";
                number=number-90;
            }else if (number>=80 && number<90){
                value=value+"LXXX";
                number=number-80;
            }else if (number>=70 && number<80){
                value=value+"LXX";
                number=number-70;
            }else if (number>=60 && number<70){
                value=value+"LX";
                number=number-60;
            }else if (number>=50 && number<60){
                value=value+"L";
                number=number-50;
            }else if (number>=40 && number<50){
                value=value+"XL";
                number=number-40;
            }else if (number>=30 && number<40){
                value=value+"XXX";
                number=number-30;
            }else if (number>=20 && number<30){
                value=value+"XX";
                number=number-20;
            }else if (number>=10 && number<20){
                value=value+"X";
                number=number-10;
            }

            if (number>=9){
                value=value+"IX";
            }else if (number>=8 && number<9){
                value=value+"VIII";
            }else if (number>=7 && number<8){
                value=value+"VII";
            }else if (number>=6 && number<7){
                value=value+"VI";
            }else if (number>=5 && number<6){
                value=value+"V";
            }else if (number>=4 && number<5){
                value=value+"IV";
            }else if (number>=3 && number<4){
                value=value+"III";
            }else if (number>=2 && number<3){
                value=value+"II";
            }else if (number>=1 && number<2){
                value=value+"I";
            }
            return value;


        }else
            throw new RuntimeException("Enter a valid number");
    }
}
