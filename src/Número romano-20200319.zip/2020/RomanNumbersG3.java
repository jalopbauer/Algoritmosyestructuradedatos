import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class RomanNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int number = scanner.nextInt();

        String[] units = {"I" , "V" , "X"};
        String[] tens = {"X" , "L" , "C"};
        String[] cents = {"C" , "D" , "M"};

        int cent = number/100;
        int decena = number/10 - cent*10;
        int unidad = number - cent*100 - decena *10;
        System.out.println(romanCorverter(cent , cents ) + romanCorverter(decena , tens) + romanCorverter(unidad , units ));
    }

    public static String romanCorverter(int a , String[] units){

        String output = "";
        int unit = a;
        switch(unit){
            case 3  : output += units[0];
            case 2  : output += units[0];
            case 1  : output += units[0];
            break;

            case 4  : output += units[0] + units[1];
            break;
            case 5  : output += units[1];
            break;
            case 6  : output += units[1] + units[0];
            break;
            case 7  : output += units[1] + units[0] + units[0];
            break;
            case 8  : output += units[1] + units[0] + units[0] + units[0];
            break;
            case 9  : output += units[0] + units[2];

        }
        return output;
    }
}
