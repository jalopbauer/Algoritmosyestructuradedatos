package TPs.TPMiniBlast;

import static org.junit.jupiter.api.Assertions.*;

class MiniBLASTTest {

    @org.junit.jupiter.api.Test
    void BLASTComparator() {
    }
}